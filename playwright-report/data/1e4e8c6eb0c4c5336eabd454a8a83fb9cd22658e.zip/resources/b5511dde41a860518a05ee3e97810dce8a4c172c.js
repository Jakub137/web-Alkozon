(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/data/products.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "mockProducts",
    ()=>mockProducts
]);
const mockProducts = [
    {
        id: "1",
        name: "Jack Daniel's",
        capacity: "0.7L",
        price: 129.99,
        image: "/products/jack-daniels.jpg",
        category: "whisky",
        alcoholContent: 40
    },
    {
        id: "2",
        name: "Belvedere",
        capacity: "0.7L",
        price: 199.99,
        image: "/products/belvedere.jpg",
        category: "vodka",
        alcoholContent: 40
    },
    {
        id: "3",
        name: "Chivas Regal 12",
        capacity: "0.7L",
        price: 149.99,
        image: "/products/chivas.jpg",
        category: "whisky",
        alcoholContent: 40
    },
    {
        id: "4",
        name: "Grey Goose",
        capacity: "0.7L",
        price: 179.99,
        image: "/products/grey-goose.jpg",
        category: "vodka",
        alcoholContent: 40
    },
    {
        id: "5",
        name: "Dom Pérignon",
        capacity: "0.75L",
        price: 899.99,
        image: "/products/dom-perignon.jpg",
        category: "wine",
        alcoholContent: 12.5
    },
    {
        id: "6",
        name: "Baileys",
        capacity: "0.7L",
        price: 89.99,
        image: "/products/baileys.jpg",
        category: "liqueur",
        alcoholContent: 17
    },
    {
        id: "7",
        name: "Heineken",
        capacity: "0.5L",
        price: 4.99,
        image: "/products/heineken.jpg",
        category: "beer",
        alcoholContent: 5
    },
    {
        id: "8",
        name: "Johnnie Walker Black Label",
        capacity: "0.7L",
        price: 159.99,
        image: "/products/johnnie-walker.jpg",
        category: "whisky",
        alcoholContent: 40
    },
    {
        id: "9",
        name: "Absolut Vodka",
        capacity: "0.7L",
        price: 79.99,
        image: "/products/absolut.jpg",
        category: "vodka",
        alcoholContent: 40
    },
    {
        id: "10",
        name: "Moët & Chandon",
        capacity: "0.75L",
        price: 299.99,
        image: "/products/moet.jpg",
        category: "wine",
        alcoholContent: 12
    },
    {
        id: "11",
        name: "Havana Club Añejo 7",
        capacity: "0.7L",
        price: 119.99,
        image: "/products/havana-club.jpg",
        category: "rum",
        alcoholContent: 40
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AgeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AgeContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ProductCard(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "ed13498fe626031a038a3b81df96a03e82d1df38931674e2cbbb0825cdfa3e71") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ed13498fe626031a038a3b81df96a03e82d1df38931674e2cbbb0825cdfa3e71";
    }
    const { product, onAddToCart, isAddDisabled: t1 } = t0;
    const isAddDisabled = t1 === undefined ? false : t1;
    const { dict } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { ageStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AgeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAge"])();
    const isDisabled = isAddDisabled || ageStatus === "underage";
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-64 bg-slate-200 dark:bg-slate-900 flex items-center justify-center p-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-6xl",
                children: "🍷"
            }, void 0, false, {
                fileName: "[project]/src/components/ProductCard.tsx",
                lineNumber: 36,
                columnNumber: 107
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 36,
            columnNumber: 10
        }, this);
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    const t3 = `/shop/${product.id}`;
    let t4;
    if ($[2] !== product.name || $[3] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: t3,
            className: "block w-full min-w-0 text-lg font-bold text-slate-800 dark:text-slate-100 mb-1 transition-colors hover:text-blue-600 dark:hover:text-blue-400 truncate",
            children: product.name
        }, void 0, false, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 44,
            columnNumber: 10
        }, this);
        $[2] = product.name;
        $[3] = t3;
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] !== product.capacity) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "block w-full min-w-0 text-sm text-slate-500 dark:text-slate-400 mb-3 transition-colors truncate",
            children: product.capacity
        }, void 0, false, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 53,
            columnNumber: 10
        }, this);
        $[5] = product.capacity;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] !== product.price) {
        t6 = product.price.toFixed(2);
        $[7] = product.price;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "block w-full text-xl font-bold text-slate-900 dark:text-slate-100 mb-4 transition-colors whitespace-nowrap truncate",
            children: [
                t6,
                " zł"
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 69,
            columnNumber: 10
        }, this);
        $[9] = t6;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== onAddToCart || $[12] !== product) {
        t8 = ({
            "ProductCard[<button>.onClick]": ()=>onAddToCart?.(product)
        })["ProductCard[<button>.onClick]"];
        $[11] = onAddToCart;
        $[12] = product;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] !== dict.shop.product.addToCart || $[15] !== isDisabled || $[16] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            disabled: isDisabled,
            onClick: t8,
            className: "w-full min-w-0 h-11 px-4 bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-800 text-white rounded-lg font-medium transition-colors flex items-center justify-center whitespace-nowrap truncate disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-blue-600 disabled:dark:hover:bg-blue-500",
            children: dict.shop.product.addToCart
        }, void 0, false, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[14] = dict.shop.product.addToCart;
        $[15] = isDisabled;
        $[16] = t8;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[18] !== t7 || $[19] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-auto",
            children: [
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 98,
            columnNumber: 11
        }, this);
        $[18] = t7;
        $[19] = t9;
        $[20] = t10;
    } else {
        t10 = $[20];
    }
    let t11;
    if ($[21] !== t10 || $[22] !== t4 || $[23] !== t5) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full sm:w-[200px] h-[400px] sm:flex-none flex flex-col min-w-0 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-sm dark:shadow-slate-900/50 hover:shadow-md dark:hover:shadow-slate-900/70 hover:border-blue-400 dark:hover:border-blue-500 transition-all group overflow-hidden",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 flex flex-col grow",
                    children: [
                        t4,
                        t5,
                        t10
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ProductCard.tsx",
                    lineNumber: 107,
                    columnNumber: 350
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ProductCard.tsx",
            lineNumber: 107,
            columnNumber: 11
        }, this);
        $[21] = t10;
        $[22] = t4;
        $[23] = t5;
        $[24] = t11;
    } else {
        t11 = $[24];
    }
    return t11;
}
_s(ProductCard, "AoF5MwaPSf7ICX1mqatUO/ChIeE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AgeContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAge"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/shop/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ShopPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data/products.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/CartContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const ITEMS_PER_PAGE = 8;
function useDebouncedValue(value, delayMs) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "4aee31a3caaf1394cf384ade766b900123450565322cfa6bc6739565e6efb5b0") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4aee31a3caaf1394cf384ade766b900123450565322cfa6bc6739565e6efb5b0";
    }
    const [debouncedValue, setDebouncedValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value);
    let t0;
    let t1;
    if ($[1] !== delayMs || $[2] !== value) {
        t0 = ({
            "useDebouncedValue[useEffect()]": ()=>{
                const timeout = window.setTimeout({
                    "useDebouncedValue[useEffect() > window.setTimeout()]": ()=>setDebouncedValue(value)
                }["useDebouncedValue[useEffect() > window.setTimeout()]"], delayMs);
                return ()=>window.clearTimeout(timeout);
            }
        })["useDebouncedValue[useEffect()]"];
        t1 = [
            value,
            delayMs
        ];
        $[1] = delayMs;
        $[2] = value;
        $[3] = t0;
        $[4] = t1;
    } else {
        t0 = $[3];
        t1 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    return debouncedValue;
}
_s(useDebouncedValue, "KDuPAtDOgxm8PU6legVJOb3oOmA=");
function ShopPage() {
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(187);
    if ($[0] !== "4aee31a3caaf1394cf384ade766b900123450565322cfa6bc6739565e6efb5b0") {
        for(let $i = 0; $i < 187; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4aee31a3caaf1394cf384ade766b900123450565322cfa6bc6739565e6efb5b0";
    }
    const { dict } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const { cartItems, cartItemsCount, cartItemsLimit, addToCart, removeFromCart } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"])();
    const categoryOptions = [
        "vodka",
        "whisky",
        "wine",
        "beer",
        "liqueur",
        "rum"
    ];
    const isCartLimitReached = cartItemsCount >= cartItemsLimit;
    let min = Number.POSITIVE_INFINITY;
    let max = Number.NEGATIVE_INFINITY;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        for (const p of __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockProducts"]){
            min = Math.min(min, p.price);
            max = Math.max(max, p.price);
        }
        $[1] = min;
        $[2] = max;
    } else {
        min = $[1];
        max = $[2];
    }
    let t0;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            min,
            max
        };
        $[3] = t0;
    } else {
        t0 = $[3];
    }
    const priceBounds = t0;
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const debouncedQuery = useDebouncedValue(query, 300);
    const [sortKey, setSortKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("nameAsc");
    let t1;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const [selectedCategories, setSelectedCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [priceMin, setPriceMin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(priceBounds.min);
    const [priceMax, setPriceMax] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(priceBounds.max);
    let t2;
    if ($[5] !== selectedCategories) {
        t2 = selectedCategories.slice().sort().join(",");
        $[5] = selectedCategories;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const selectedCategoriesKey = t2;
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    let t3;
    if ($[7] !== setCurrentPage) {
        t3 = ({
            "ShopPage[useEffect()]": ()=>{
                setCurrentPage(1);
            }
        })["ShopPage[useEffect()]"];
        $[7] = setCurrentPage;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== debouncedQuery || $[10] !== priceMax || $[11] !== priceMin || $[12] !== selectedCategoriesKey || $[13] !== sortKey) {
        t4 = [
            debouncedQuery,
            sortKey,
            selectedCategoriesKey,
            priceMin,
            priceMax
        ];
        $[9] = debouncedQuery;
        $[10] = priceMax;
        $[11] = priceMin;
        $[12] = selectedCategoriesKey;
        $[13] = sortKey;
        $[14] = t4;
    } else {
        t4 = $[14];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let sorted;
    if ($[15] !== debouncedQuery || $[16] !== priceMax || $[17] !== priceMin || $[18] !== selectedCategories || $[19] !== sortKey) {
        const q = debouncedQuery.trim().toLowerCase();
        const min_0 = Math.min(priceMin, priceMax);
        const max_0 = Math.max(priceMin, priceMax);
        const filtered = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockProducts"].filter({
            "ShopPage[mockProducts.filter()]": (p_0)=>{
                const matchQuery = q.length === 0 || p_0.name.toLowerCase().includes(q);
                const matchCategory = selectedCategories.length === 0 || selectedCategories.includes(p_0.category);
                const matchPrice = p_0.price >= min_0 && p_0.price <= max_0;
                return matchQuery && matchCategory && matchPrice;
            }
        }["ShopPage[mockProducts.filter()]"]);
        sorted = filtered.slice();
        let t5;
        if ($[21] !== sortKey) {
            t5 = ({
                "ShopPage[sorted.sort()]": (a, b)=>{
                    switch(sortKey){
                        case "priceAsc":
                            {
                                return a.price - b.price;
                            }
                        case "priceDesc":
                            {
                                return b.price - a.price;
                            }
                        case "nameAsc":
                            {
                                return a.name.localeCompare(b.name);
                            }
                        case "nameDesc":
                            {
                                return b.name.localeCompare(a.name);
                            }
                    }
                }
            })["ShopPage[sorted.sort()]"];
            $[21] = sortKey;
            $[22] = t5;
        } else {
            t5 = $[22];
        }
        sorted.sort(t5);
        $[15] = debouncedQuery;
        $[16] = priceMax;
        $[17] = priceMin;
        $[18] = selectedCategories;
        $[19] = sortKey;
        $[20] = sorted;
    } else {
        sorted = $[20];
    }
    const filteredAndSorted = sorted;
    const totalPages = Math.max(1, Math.ceil(filteredAndSorted.length / ITEMS_PER_PAGE));
    let t5;
    if ($[23] !== setCurrentPage || $[24] !== totalPages) {
        t5 = ({
            "ShopPage[useEffect()]": ()=>{
                setCurrentPage({
                    "ShopPage[useEffect() > setCurrentPage()]": (prev)=>Math.min(prev, totalPages)
                }["ShopPage[useEffect() > setCurrentPage()]"]);
            }
        })["ShopPage[useEffect()]"];
        $[23] = setCurrentPage;
        $[24] = totalPages;
        $[25] = t5;
    } else {
        t5 = $[25];
    }
    let t6;
    if ($[26] !== totalPages) {
        t6 = [
            totalPages
        ];
        $[26] = totalPages;
        $[27] = t6;
    } else {
        t6 = $[27];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t5, t6);
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    let t7;
    if ($[28] !== end || $[29] !== filteredAndSorted || $[30] !== start) {
        t7 = filteredAndSorted.slice(start, end);
        $[28] = end;
        $[29] = filteredAndSorted;
        $[30] = start;
        $[31] = t7;
    } else {
        t7 = $[31];
    }
    const pageItems = t7;
    let t8;
    bb0: {
        const total = totalPages;
        if (total <= 5) {
            let t9;
            if ($[32] !== total) {
                t9 = Array.from({
                    length: total
                }, _ShopPageArrayFrom);
                $[32] = total;
                $[33] = t9;
            } else {
                t9 = $[33];
            }
            t8 = t9;
            break bb0;
        }
        let start_0 = Math.max(1, currentPage - 2);
        const end_0 = Math.min(total, start_0 + 5 - 1);
        start_0 = Math.max(1, end_0 - 5 + 1);
        let pages;
        if ($[34] !== end_0 || $[35] !== start_0) {
            pages = [];
            for(let i_0 = start_0; i_0 <= end_0; i_0++){
                pages.push(i_0);
            }
            $[34] = end_0;
            $[35] = start_0;
            $[36] = pages;
        } else {
            pages = $[36];
        }
        t8 = pages;
    }
    const visiblePages = t8;
    const toggleCategory = {
        "ShopPage[toggleCategory]": (cat)=>{
            setSelectedCategories({
                "ShopPage[toggleCategory > setSelectedCategories()]": (prev_0)=>prev_0.includes(cat) ? prev_0.filter({
                        "ShopPage[toggleCategory > setSelectedCategories() > prev_0.filter()]": (x)=>x !== cat
                    }["ShopPage[toggleCategory > setSelectedCategories() > prev_0.filter()]"]) : [
                        ...prev_0,
                        cat
                    ]
            }["ShopPage[toggleCategory > setSelectedCategories()]"]);
        }
    }["ShopPage[toggleCategory]"];
    const t9 = "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grow flex flex-col";
    let t10;
    if ($[37] !== dict.shop.title) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-slate-100 mb-4 transition-colors",
            children: dict.shop.title
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 276,
            columnNumber: 11
        }, this);
        $[37] = dict.shop.title;
        $[38] = t10;
    } else {
        t10 = $[38];
    }
    let t11;
    if ($[39] !== dict.shop.subtitle) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto transition-colors",
            children: dict.shop.subtitle
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 284,
            columnNumber: 11
        }, this);
        $[39] = dict.shop.subtitle;
        $[40] = t11;
    } else {
        t11 = $[40];
    }
    let t12;
    if ($[41] !== t10 || $[42] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "mb-8 text-center",
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 292,
            columnNumber: 11
        }, this);
        $[41] = t10;
        $[42] = t11;
        $[43] = t12;
    } else {
        t12 = $[43];
    }
    const t13 = "flex flex-col lg:flex-row gap-6 flex-1";
    const t14 = "w-full lg:w-64 lg:min-w-64 lg:max-w-64 shrink-0";
    const t15 = "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-sm dark:shadow-slate-900/50";
    let t16;
    if ($[44] !== dict.shop.filters.title) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-xl font-bold text-slate-800 dark:text-slate-100 mb-4 transition-colors",
            children: dict.shop.filters.title
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 304,
            columnNumber: 11
        }, this);
        $[44] = dict.shop.filters.title;
        $[45] = t16;
    } else {
        t16 = $[45];
    }
    const t17 = "space-y-6";
    let t18;
    if ($[46] !== dict.shop.filters.category) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3 transition-colors",
            children: dict.shop.filters.category
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 313,
            columnNumber: 11
        }, this);
        $[46] = dict.shop.filters.category;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    const t19 = "space-y-3";
    const t20 = categoryOptions.map({
        "ShopPage[categoryOptions.map()]": (cat_0)=>{
            const checked = selectedCategories.includes(cat_0);
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "flex items-center gap-3 text-sm text-slate-700 dark:text-slate-300 select-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "checkbox",
                        checked: checked,
                        onChange: {
                            "ShopPage[categoryOptions.map() > <input>.onChange]": ()=>toggleCategory(cat_0)
                        }["ShopPage[categoryOptions.map() > <input>.onChange]"],
                        className: "h-4 w-4 rounded border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 focus:ring-2 focus:ring-blue-500"
                    }, void 0, false, {
                        fileName: "[project]/src/app/shop/page.tsx",
                        lineNumber: 323,
                        columnNumber: 124
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "truncate",
                        children: dict.shop.categories[cat_0]
                    }, void 0, false, {
                        fileName: "[project]/src/app/shop/page.tsx",
                        lineNumber: 325,
                        columnNumber: 195
                    }, this)
                ]
            }, cat_0, true, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 323,
                columnNumber: 14
            }, this);
        }
    }["ShopPage[categoryOptions.map()]"]);
    let t21;
    if ($[48] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t19,
            children: t20
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 330,
            columnNumber: 11
        }, this);
        $[48] = t20;
        $[49] = t21;
    } else {
        t21 = $[49];
    }
    let t22;
    if ($[50] !== t18 || $[51] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t18,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 338,
            columnNumber: 11
        }, this);
        $[50] = t18;
        $[51] = t21;
        $[52] = t22;
    } else {
        t22 = $[52];
    }
    let t23;
    if ($[53] !== dict.shop.filters.priceRange) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3 transition-colors",
            children: dict.shop.filters.priceRange
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 347,
            columnNumber: 11
        }, this);
        $[53] = dict.shop.filters.priceRange;
        $[54] = t23;
    } else {
        t23 = $[54];
    }
    let t24;
    if ($[55] !== dict.shop.filters.priceMin) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
            children: dict.shop.filters.priceMin
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 355,
            columnNumber: 11
        }, this);
        $[55] = dict.shop.filters.priceMin;
        $[56] = t24;
    } else {
        t24 = $[56];
    }
    let t25;
    if ($[57] !== priceMin) {
        t25 = Number.isFinite(priceMin) ? priceMin : 0;
        $[57] = priceMin;
        $[58] = t25;
    } else {
        t25 = $[58];
    }
    let t26;
    if ($[59] !== setPriceMin) {
        t26 = ({
            "ShopPage[<input>.onChange]": (e)=>setPriceMin(Number(e.target.value))
        })["ShopPage[<input>.onChange]"];
        $[59] = setPriceMin;
        $[60] = t26;
    } else {
        t26 = $[60];
    }
    let t27;
    if ($[61] !== priceBounds.max || $[62] !== priceBounds.min || $[63] !== t25 || $[64] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "number",
            value: t25,
            step: 0.01,
            min: priceBounds.min,
            max: priceBounds.max,
            onChange: t26,
            className: "w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[61] = priceBounds.max;
        $[62] = priceBounds.min;
        $[63] = t25;
        $[64] = t26;
        $[65] = t27;
    } else {
        t27 = $[65];
    }
    let t28;
    if ($[66] !== t24 || $[67] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t24,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 392,
            columnNumber: 11
        }, this);
        $[66] = t24;
        $[67] = t27;
        $[68] = t28;
    } else {
        t28 = $[68];
    }
    let t29;
    if ($[69] !== dict.shop.filters.priceMax) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
            children: dict.shop.filters.priceMax
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 401,
            columnNumber: 11
        }, this);
        $[69] = dict.shop.filters.priceMax;
        $[70] = t29;
    } else {
        t29 = $[70];
    }
    let t30;
    if ($[71] !== priceMax) {
        t30 = Number.isFinite(priceMax) ? priceMax : 0;
        $[71] = priceMax;
        $[72] = t30;
    } else {
        t30 = $[72];
    }
    let t31;
    if ($[73] !== setPriceMax) {
        t31 = ({
            "ShopPage[<input>.onChange]": (e_0)=>setPriceMax(Number(e_0.target.value))
        })["ShopPage[<input>.onChange]"];
        $[73] = setPriceMax;
        $[74] = t31;
    } else {
        t31 = $[74];
    }
    let t32;
    if ($[75] !== priceBounds.max || $[76] !== priceBounds.min || $[77] !== t30 || $[78] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "number",
            value: t30,
            step: 0.01,
            min: priceBounds.min,
            max: priceBounds.max,
            onChange: t31,
            className: "w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 427,
            columnNumber: 11
        }, this);
        $[75] = priceBounds.max;
        $[76] = priceBounds.min;
        $[77] = t30;
        $[78] = t31;
        $[79] = t32;
    } else {
        t32 = $[79];
    }
    let t33;
    if ($[80] !== t29 || $[81] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t29,
                t32
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 438,
            columnNumber: 11
        }, this);
        $[80] = t29;
        $[81] = t32;
        $[82] = t33;
    } else {
        t33 = $[82];
    }
    let t34;
    if ($[83] !== t28 || $[84] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 gap-3",
            children: [
                t28,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 447,
            columnNumber: 11
        }, this);
        $[83] = t28;
        $[84] = t33;
        $[85] = t34;
    } else {
        t34 = $[85];
    }
    const t35 = Math.min(priceMin, priceMax);
    let t36;
    if ($[86] !== t35) {
        t36 = t35.toFixed(2);
        $[86] = t35;
        $[87] = t36;
    } else {
        t36 = $[87];
    }
    let t37;
    if ($[88] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: [
                t36,
                " zł"
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 465,
            columnNumber: 11
        }, this);
        $[88] = t36;
        $[89] = t37;
    } else {
        t37 = $[89];
    }
    const t38 = Math.max(priceMin, priceMax);
    let t39;
    if ($[90] !== t38) {
        t39 = t38.toFixed(2);
        $[90] = t38;
        $[91] = t39;
    } else {
        t39 = $[91];
    }
    let t40;
    if ($[92] !== t39) {
        t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: [
                t39,
                " zł"
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 482,
            columnNumber: 11
        }, this);
        $[92] = t39;
        $[93] = t40;
    } else {
        t40 = $[93];
    }
    let t41;
    if ($[94] !== t37 || $[95] !== t40) {
        t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-4 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400",
            children: [
                t37,
                t40
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 490,
            columnNumber: 11
        }, this);
        $[94] = t37;
        $[95] = t40;
        $[96] = t41;
    } else {
        t41 = $[96];
    }
    let t42;
    if ($[97] !== t23 || $[98] !== t34 || $[99] !== t41) {
        t42 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t23,
                t34,
                t41
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 499,
            columnNumber: 11
        }, this);
        $[97] = t23;
        $[98] = t34;
        $[99] = t41;
        $[100] = t42;
    } else {
        t42 = $[100];
    }
    let t43;
    if ($[101] !== t22 || $[102] !== t42) {
        t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t17,
            children: [
                t22,
                t42
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 509,
            columnNumber: 11
        }, this);
        $[101] = t22;
        $[102] = t42;
        $[103] = t43;
    } else {
        t43 = $[103];
    }
    let t44;
    if ($[104] !== t16 || $[105] !== t43) {
        t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
            className: t14,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: t15,
                children: [
                    t16,
                    t43
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 518,
                columnNumber: 34
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 518,
            columnNumber: 11
        }, this);
        $[104] = t16;
        $[105] = t43;
        $[106] = t44;
    } else {
        t44 = $[106];
    }
    let t45;
    if ($[107] !== setQuery) {
        t45 = ({
            "ShopPage[<input>.onChange]": (e_1)=>setQuery(e_1.target.value)
        })["ShopPage[<input>.onChange]"];
        $[107] = setQuery;
        $[108] = t45;
    } else {
        t45 = $[108];
    }
    let t46;
    if ($[109] !== dict.shop.search.placeholder || $[110] !== query || $[111] !== t45) {
        t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "text",
                placeholder: dict.shop.search.placeholder,
                className: "w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors",
                value: query,
                onChange: t45
            }, void 0, false, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 537,
                columnNumber: 35
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 537,
            columnNumber: 11
        }, this);
        $[109] = dict.shop.search.placeholder;
        $[110] = query;
        $[111] = t45;
        $[112] = t46;
    } else {
        t46 = $[112];
    }
    let t47;
    if ($[113] !== setSortKey) {
        t47 = ({
            "ShopPage[<select>.onChange]": (e_2)=>setSortKey(e_2.target.value)
        })["ShopPage[<select>.onChange]"];
        $[113] = setSortKey;
        $[114] = t47;
    } else {
        t47 = $[114];
    }
    let t48;
    if ($[115] !== dict.shop.sort.priceAsc) {
        t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "priceAsc",
            children: dict.shop.sort.priceAsc
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 557,
            columnNumber: 11
        }, this);
        $[115] = dict.shop.sort.priceAsc;
        $[116] = t48;
    } else {
        t48 = $[116];
    }
    let t49;
    if ($[117] !== dict.shop.sort.priceDesc) {
        t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "priceDesc",
            children: dict.shop.sort.priceDesc
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 565,
            columnNumber: 11
        }, this);
        $[117] = dict.shop.sort.priceDesc;
        $[118] = t49;
    } else {
        t49 = $[118];
    }
    let t50;
    if ($[119] !== dict.shop.sort.nameAsc) {
        t50 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "nameAsc",
            children: dict.shop.sort.nameAsc
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 573,
            columnNumber: 11
        }, this);
        $[119] = dict.shop.sort.nameAsc;
        $[120] = t50;
    } else {
        t50 = $[120];
    }
    let t51;
    if ($[121] !== dict.shop.sort.nameDesc) {
        t51 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "nameDesc",
            children: dict.shop.sort.nameDesc
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 581,
            columnNumber: 11
        }, this);
        $[121] = dict.shop.sort.nameDesc;
        $[122] = t51;
    } else {
        t51 = $[122];
    }
    let t52;
    if ($[123] !== sortKey || $[124] !== t47 || $[125] !== t48 || $[126] !== t49 || $[127] !== t50 || $[128] !== t51) {
        t52 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full sm:w-48",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                className: "w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors",
                value: sortKey,
                onChange: t47,
                children: [
                    t48,
                    t49,
                    t50,
                    t51
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 589,
                columnNumber: 43
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 589,
            columnNumber: 11
        }, this);
        $[123] = sortKey;
        $[124] = t47;
        $[125] = t48;
        $[126] = t49;
        $[127] = t50;
        $[128] = t51;
        $[129] = t52;
    } else {
        t52 = $[129];
    }
    let t53;
    if ($[130] !== t46 || $[131] !== t52) {
        t53 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 mb-6 shadow-sm dark:shadow-slate-900/50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row gap-4",
                children: [
                    t46,
                    t52
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 602,
                columnNumber: 157
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 602,
            columnNumber: 11
        }, this);
        $[130] = t46;
        $[131] = t52;
        $[132] = t53;
    } else {
        t53 = $[132];
    }
    let t54;
    if ($[133] !== addToCart || $[134] !== currentPage || $[135] !== dict.shop.noProducts || $[136] !== dict.shop.pagination || $[137] !== filteredAndSorted.length || $[138] !== isCartLimitReached || $[139] !== pageItems || $[140] !== setCurrentPage || $[141] !== totalPages || $[142] !== visiblePages) {
        t54 = filteredAndSorted.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-8 text-center text-slate-600 dark:text-slate-300 shadow-sm dark:shadow-slate-900/50",
            children: dict.shop.noProducts
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 611,
            columnNumber: 44
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6",
                    children: pageItems.map({
                        "ShopPage[pageItems.map()]": (product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                product: product,
                                onAddToCart: addToCart,
                                isAddDisabled: isCartLimitReached
                            }, product.id, false, {
                                fileName: "[project]/src/app/shop/page.tsx",
                                lineNumber: 612,
                                columnNumber: 51
                            }, this)
                    }["ShopPage[pageItems.map()]"])
                }, void 0, false, {
                    fileName: "[project]/src/app/shop/page.tsx",
                    lineNumber: 611,
                    columnNumber: 265
                }, this),
                totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-auto pt-8 flex items-center justify-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: {
                                "ShopPage[<button>.onClick]": ()=>setCurrentPage(_ShopPageButtonOnClickSetCurrentPage)
                            }["ShopPage[<button>.onClick]"],
                            disabled: currentPage === 1,
                            className: "h-10 min-w-[90px] px-4 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                            "aria-label": dict.shop.pagination.prev,
                            children: dict.shop.pagination.prev
                        }, void 0, false, {
                            fileName: "[project]/src/app/shop/page.tsx",
                            lineNumber: 613,
                            columnNumber: 135
                        }, this),
                        visiblePages.map({
                            "ShopPage[visiblePages.map()]": (page)=>{
                                const active = page === currentPage;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: {
                                        "ShopPage[visiblePages.map() > <button>.onClick]": ()=>setCurrentPage(page)
                                    }["ShopPage[visiblePages.map() > <button>.onClick]"],
                                    "aria-current": active ? "page" : undefined,
                                    className: `h-10 w-10 rounded-lg border transition-colors ${active ? "bg-blue-600 border-blue-600 text-white border-blue-600" : "bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-800 dark:text-slate-100 hover:border-blue-500"}`,
                                    children: page
                                }, page, false, {
                                    fileName: "[project]/src/app/shop/page.tsx",
                                    lineNumber: 618,
                                    columnNumber: 20
                                }, this);
                            }
                        }["ShopPage[visiblePages.map()]"]),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: {
                                "ShopPage[<button>.onClick]": ()=>setCurrentPage({
                                        "ShopPage[<button>.onClick > setCurrentPage()]": (p_2)=>Math.min(totalPages, p_2 + 1)
                                    }["ShopPage[<button>.onClick > setCurrentPage()]"])
                            }["ShopPage[<button>.onClick]"],
                            disabled: currentPage === totalPages,
                            className: "h-10 min-w-[90px] px-4 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                            "aria-label": dict.shop.pagination.next,
                            children: dict.shop.pagination.next
                        }, void 0, false, {
                            fileName: "[project]/src/app/shop/page.tsx",
                            lineNumber: 622,
                            columnNumber: 44
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/shop/page.tsx",
                    lineNumber: 613,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true);
        $[133] = addToCart;
        $[134] = currentPage;
        $[135] = dict.shop.noProducts;
        $[136] = dict.shop.pagination;
        $[137] = filteredAndSorted.length;
        $[138] = isCartLimitReached;
        $[139] = pageItems;
        $[140] = setCurrentPage;
        $[141] = totalPages;
        $[142] = visiblePages;
        $[143] = t54;
    } else {
        t54 = $[143];
    }
    let t55;
    if ($[144] !== t53 || $[145] !== t54) {
        t55 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col",
            children: [
                t53,
                t54
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 643,
            columnNumber: 11
        }, this);
        $[144] = t53;
        $[145] = t54;
        $[146] = t55;
    } else {
        t55 = $[146];
    }
    let t56;
    if ($[147] !== t44 || $[148] !== t55) {
        t56 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t13,
            children: [
                t44,
                t55
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 652,
            columnNumber: 11
        }, this);
        $[147] = t44;
        $[148] = t55;
        $[149] = t56;
    } else {
        t56 = $[149];
    }
    let t57;
    if ($[150] === Symbol.for("react.memo_cache_sentinel")) {
        t57 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-3xl leading-none",
            children: "🛒"
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 661,
            columnNumber: 11
        }, this);
        $[150] = t57;
    } else {
        t57 = $[150];
    }
    let t58;
    if ($[151] !== cartItemsCount) {
        t58 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative shrink-0",
            children: [
                t57,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "absolute -top-2 -left-2 min-w-5 h-5 px-1 rounded-full bg-blue-600 text-white text-[11px] font-bold flex items-center justify-center",
                    children: cartItemsCount
                }, void 0, false, {
                    fileName: "[project]/src/app/shop/page.tsx",
                    lineNumber: 668,
                    columnNumber: 51
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 668,
            columnNumber: 11
        }, this);
        $[151] = cartItemsCount;
        $[152] = t58;
    } else {
        t58 = $[152];
    }
    let t59;
    if ($[153] !== dict.shop.cart.title) {
        t59 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-sm font-bold text-slate-900 dark:text-slate-100",
            children: dict.shop.cart.title
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 676,
            columnNumber: 11
        }, this);
        $[153] = dict.shop.cart.title;
        $[154] = t59;
    } else {
        t59 = $[154];
    }
    let t60;
    if ($[155] !== cartItemsCount || $[156] !== dict.shop.cart.items) {
        t60 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xs text-slate-500 dark:text-slate-400",
            children: [
                dict.shop.cart.items,
                ": ",
                cartItemsCount
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 684,
            columnNumber: 11
        }, this);
        $[155] = cartItemsCount;
        $[156] = dict.shop.cart.items;
        $[157] = t60;
    } else {
        t60 = $[157];
    }
    let t61;
    if ($[158] !== cartItemsLimit || $[159] !== dict.shop.cart.limit) {
        t61 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-xs text-slate-500 dark:text-slate-400",
            children: [
                dict.shop.cart.limit,
                ": ",
                cartItemsLimit
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 693,
            columnNumber: 11
        }, this);
        $[158] = cartItemsLimit;
        $[159] = dict.shop.cart.limit;
        $[160] = t61;
    } else {
        t61 = $[160];
    }
    let t62;
    if ($[161] !== t59 || $[162] !== t60 || $[163] !== t61) {
        t62 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-w-0",
            children: [
                t59,
                t60,
                t61
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 702,
            columnNumber: 11
        }, this);
        $[161] = t59;
        $[162] = t60;
        $[163] = t61;
        $[164] = t62;
    } else {
        t62 = $[164];
    }
    let t63;
    if ($[165] !== t58 || $[166] !== t62) {
        t63 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start gap-3 mb-3",
            children: [
                t58,
                t62
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 712,
            columnNumber: 11
        }, this);
        $[165] = t58;
        $[166] = t62;
        $[167] = t63;
    } else {
        t63 = $[167];
    }
    let t64;
    if ($[168] !== dict.shop.cart.limitReached || $[169] !== isCartLimitReached) {
        t64 = isCartLimitReached && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "mb-3 text-xs text-red-600 dark:text-red-400",
            children: dict.shop.cart.limitReached
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 721,
            columnNumber: 33
        }, this);
        $[168] = dict.shop.cart.limitReached;
        $[169] = isCartLimitReached;
        $[170] = t64;
    } else {
        t64 = $[170];
    }
    let t65;
    if ($[171] !== cartItems || $[172] !== dict.shop.cart.empty || $[173] !== dict.shop.cart.remove || $[174] !== removeFromCart) {
        t65 = cartItems.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-slate-500 dark:text-slate-400",
            children: dict.shop.cart.empty
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 730,
            columnNumber: 36
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
            className: "max-h-44 overflow-y-auto space-y-2 pr-1",
            children: cartItems.map({
                "ShopPage[cartItems.map()]": (item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "text-sm text-slate-700 dark:text-slate-200 flex items-center justify-between gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "truncate",
                                children: item.product.name
                            }, void 0, false, {
                                fileName: "[project]/src/app/shop/page.tsx",
                                lineNumber: 731,
                                columnNumber: 167
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "shrink-0 flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-slate-500 dark:text-slate-400",
                                        children: [
                                            "x",
                                            item.quantity
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/shop/page.tsx",
                                        lineNumber: 731,
                                        columnNumber: 270
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: {
                                            "ShopPage[cartItems.map() > <button>.onClick]": ()=>removeFromCart(item.product.id)
                                        }["ShopPage[cartItems.map() > <button>.onClick]"],
                                        className: "h-7 px-2 rounded-md border border-slate-300 dark:border-slate-600 text-xs text-slate-700 dark:text-slate-200 hover:border-red-500 hover:text-red-600 dark:hover:text-red-400 transition-colors",
                                        "aria-label": dict.shop.cart.remove,
                                        children: dict.shop.cart.remove
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/shop/page.tsx",
                                        lineNumber: 731,
                                        columnNumber: 354
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/shop/page.tsx",
                                lineNumber: 731,
                                columnNumber: 220
                            }, this)
                        ]
                    }, item.product.id, true, {
                        fileName: "[project]/src/app/shop/page.tsx",
                        lineNumber: 731,
                        columnNumber: 46
                    }, this)
            }["ShopPage[cartItems.map()]"])
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 730,
            columnNumber: 123
        }, this);
        $[171] = cartItems;
        $[172] = dict.shop.cart.empty;
        $[173] = dict.shop.cart.remove;
        $[174] = removeFromCart;
        $[175] = t65;
    } else {
        t65 = $[175];
    }
    let t66;
    if ($[176] !== dict.shop.cart.summary) {
        t66 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/cart?from=shop",
            className: "mt-3 w-full h-10 px-3 inline-flex items-center justify-center rounded-lg bg-green-600 hover:bg-green-600 dark:bg-green-500 dark:hover:bg-green-700 text-white text-sm font-medium transition-colors",
            children: dict.shop.cart.summary
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 745,
            columnNumber: 11
        }, this);
        $[176] = dict.shop.cart.summary;
        $[177] = t66;
    } else {
        t66 = $[177];
    }
    let t67;
    if ($[178] !== t63 || $[179] !== t64 || $[180] !== t65 || $[181] !== t66) {
        t67 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed bottom-4 left-4 sm:bottom-6 sm:right-6 z-40 w-72 max-w-[calc(100vw-2rem)]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-xl dark:shadow-slate-900/60 p-4",
                children: [
                    t63,
                    t64,
                    t65,
                    t66
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/shop/page.tsx",
                lineNumber: 753,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 753,
            columnNumber: 11
        }, this);
        $[178] = t63;
        $[179] = t64;
        $[180] = t65;
        $[181] = t66;
        $[182] = t67;
    } else {
        t67 = $[182];
    }
    let t68;
    if ($[183] !== t12 || $[184] !== t56 || $[185] !== t67) {
        t68 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t9,
            children: [
                t12,
                t56,
                t67
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/shop/page.tsx",
            lineNumber: 764,
            columnNumber: 11
        }, this);
        $[183] = t12;
        $[184] = t56;
        $[185] = t67;
        $[186] = t68;
    } else {
        t68 = $[186];
    }
    return t68;
}
_s1(ShopPage, "1DjADKMe7PdgpTXeGPovMAiWEd8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$CartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCart"],
        useDebouncedValue
    ];
});
_c = ShopPage;
function _ShopPageButtonOnClickSetCurrentPage(p_1) {
    return Math.max(1, p_1 - 1);
}
function _ShopPageArrayFrom(_, i) {
    return i + 1;
}
var _c;
__turbopack_context__.k.register(_c, "ShopPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_dca4117f._.js.map